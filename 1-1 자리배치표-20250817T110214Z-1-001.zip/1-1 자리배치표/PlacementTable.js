const start = document.getElementById("start");
const seatGroup = [];
const left = document.getElementsByClassName("left")[0];

let name_list = [];

function refill() {
    name_list.push(
    "1. 강윤아",
    "2. 김가영",
    "3. 김도원",
    "4. 김문경",
    "5. 김민재", 
    "6. 김연희", 
    "7. 김재광",
    "8. 김재원",
    "9. 김태율",
    "10. 김하성",
    "11. 김하진",
    "12. 박시연",
    "13. 박하영",
    "14. 박하은",
    "15. 선채오",
    "16. 신지호",
    "17. 엄윤찬",
    "18. 이도경",
    "19. 이동주",
    "20. 이산을",
    "21. 이서희",
    "22. 이지윤",
    "23. 이현서",
    "24. 정수연",
    "25. 최민기",
    "26. 최시우",
    "27. 최윤우",
    "28. 최준호",
    "29. 최지수",
    "30. 홍지석",
    "31. 황서연");
}

refill();

start.addEventListener("click", () => {
    let random_name_list = [];
    for (let k = 1; k <= 31; k++) {
        random_index = Math.floor(Math.random() * name_list.length);
        random_name_list.push(name_list[random_index]);
        name_list.splice(random_index, 1);
    }
    refill();

    for (let l = 1; l <= 30; l++) {
        const seat = document.getElementsByClassName(`${l}`)[0];
        seat.textContent = random_name_list[l-1];
    }
    left.textContent = `나머지 : ${random_name_list[30]}`;
})